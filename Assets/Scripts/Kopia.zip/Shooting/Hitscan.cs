﻿
using UnityEngine;

public class Hitscan : MonoBehaviour
{

    public float damage = 10f;
    public float destroyTime;
    private Camera cam;
    public GameObject slad;
    // Start is called before the first frame update
    void Start()
    {
        cam = GameObject.Find("mainCamera").GetComponent<Camera>();
    }
    // Update is called once per frame
    void Update()
    {
        if (Input.GetButton("Fire1"))
        {
            Shoot();
        }
    }

    void Shoot()
    {
        Debug.Log("Strzelanie");
        RaycastHit hit;
        if (Physics.Raycast(cam.transform.position, cam.transform.forward, out hit))
        {
            Debug.Log("Namierzony obiekt: " + hit.transform.name);
            ITarget target = hit.transform.GetComponent<ITarget>();
            if(target!=null)
            {
                target.TakeDamage(damage);
                Debug.Log("Pozostałe życie: "+ target.getHealth());
            }
            GameObject obiekt=Instantiate(slad, hit.point, Quaternion.LookRotation(hit.normal));
            Destroy(obiekt, destroyTime);
        }
    }
}
